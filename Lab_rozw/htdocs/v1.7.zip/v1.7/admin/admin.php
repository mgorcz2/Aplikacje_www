<?php

// -----------------------------------------------------------------------------
// Plik administracyjny
// Funkcje zarządzania: logowanie, dodawanie, edycja i usuwanie podstron
// -----------------------------------------------------------------------------

session_start();
require("cfg.php");

// Funkcja do logowania użytkownika
function FormularzLogowania()
{
    $wynik = '
    <div class="logowanie">
        <h1 class="heading">Panel CMS:</h1>
        <div class="logowanie">
            <form method="post" name="LoginForm" enctype="multipart/form-data" action="' . htmlspecialchars($_SERVER['REQUEST_URI']) . '">
                <table class="logowanie">
                    <tr>
                        <td class="log4_t">[email]</td>
                        <td><input type="text" name="login_email" class="logowanie" /></td>
                    </tr>
                    <tr>
                        <td class="log4_t">[haslo]</td>
                        <td><input type="password" name="login_pass" class="logowanie" /></td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td><input type="submit" name="x1_submit" class="logowanie" value="zaloguj" /></td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td><input type="submit" name="skip_login" class="logowanie" value="Pomiń logowanie" /></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
    ';

    return $wynik;
}

// Sprawdzanie czy użytkownik chce pominąć logowanie
if (isset($_POST['skip_login'])) {
    $_SESSION['is_logged_in'] = true;
    header("Location: index.php?idp=calc"); // Przekierowanie na stronę główną po pominięciu logowania
    exit; // Przerywamy dalsze wykonanie
}

// Jeśli formularz logowania został wysłany
if (isset($_POST['x1_submit'])) {                   
    $email = $_POST['login_email'] ?? '';
    $password = $_POST['login_pass'] ?? '';
    if ($email === $login && $password === $pass) {
        $_SESSION['is_logged_in'] = true;
        $admin = TRUE;
    } else {
        echo 'Błędny login lub hasło.';
        exit; 
    }
}

// Jeśli nie ma sesji z logowaniem i nie jest pominięte logowanie
if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    echo FormularzLogowania();
    exit; // Przerywamy dalsze wykonanie, jeśli użytkownik nie jest zalogowany
}
function ListaPodstron() {
    global $link;

    // Zapytanie do bazy danych, aby pobrać wszystkie podstrony
    $query = "SELECT id, page_title FROM page_list"; 
    $result = mysqli_query($link, $query);

    if ($result) {
        echo '<table border="1" cellpadding="5">';
        echo '<tr><th>ID</th><th>Tytuł</th><th>Opcje</th></tr>';
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td>' . $row['id'] . '</td>';
            echo '<td>' . $row['page_title'] . '</td>';
            echo '<td>
                    <form method="post" action="">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" value="' . $row['id'] . '">
                        <input type="submit" value="Edytuj" />
                    </form>
                    <form method="post" action="">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="' . $row['id'] . '">
                        <input type="submit" value="Usuń" onclick="return confirm(\'Czy na pewno chcesz usunąć tę podstronę?\')" />
                    </form>
                  </td>';
            echo '</tr>';
        }
        echo '</table>';
        echo '<hr>';
    } else {
        echo 'Wystąpił błąd podczas pobierania danych z bazy.';
    }

    #edycja
    if (isset($_POST['action']) && $_POST['action'] == 'edit' && isset($_POST['id'])) {
        $id = $_POST['id'];

        // Pobranie danych podstrony z bazy
        $query = "SELECT * FROM page_list WHERE id = $id LIMIT 1";
        $result = mysqli_query($link, $query);
        
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);

            echo '<h3>Edytuj Podstronę</h3>';
            echo '<form method="post" action="">
                    Tytuł: <input type="text" name="page_title" value="' . $row['page_title'] . '" required /><br>
                    Treść: <textarea name="content" required>' . $row['page_content'] . '</textarea><br>
                    Aktywna: <input type="checkbox" name="active" ' . ($row['status'] == 1 ? 'checked' : '') . ' /><br>
                    <input type="hidden" name="action" value="update" />
                    <input type="hidden" name="id" value="' . $row['id'] . '" />
                    <input type="submit" value="Zapisz" />
                  </form>';
        } else {
            echo "Nie znaleziono podstrony o tym ID.";
        }
    }
#aktualizacja
    if (isset($_POST['action']) && $_POST['action'] == 'update' && isset($_POST['id'])) {
        $id = $_POST['id'];
        $page_title = $_POST['page_title'];
        $content = $_POST['content'];
        $active = isset($_POST['active']) ? 1 : 0;

        $query = "UPDATE page_list SET page_title = '$page_title', page_content = '$content', status = $active WHERE id = $id LIMIT 1";
        
        if (mysqli_query($link, $query)) {
            echo "Podstrona została zaktualizowana!";
        } else {
            echo "Błąd aktualizacji: " . mysqli_error($link);
        }
    }

#usuniecie
    if (isset($_POST['action']) && $_POST['action'] == 'delete' && isset($_POST['id'])) {
        $id = $_POST['id'];

        // Usunięcie podstrony z bazy danych
        $query = "DELETE FROM page_list WHERE id = $id LIMIT 1";
        
        if (mysqli_query($link, $query)) {
            echo "Podstrona została usunięta!";
        } else {
            echo "Błąd usuwania podstrony: " . mysqli_error($link);
        }
    }
}
echo '<br><br><h2>Witaj w panelu administracyjnym!</h2>';
ListaPodstron();


//Funkcja do dodawania podstron
function DodajNowaPodstrone() {
    global $link;

    if (isset($_POST['action']) && $_POST['action'] == 'add') {
        $page_title = $_POST['page_title'];
        $content = $_POST['content'];
        $active = isset($_POST['active']) ? 1 : 0;

        $query = "INSERT INTO page_list (page_title, page_content, status) 
                  VALUES ('$page_title', '$content', $active) LIMIT 1";
        if (mysqli_query($link, $query)) {
            echo "Nowa podstrona została dodana!";
        } else {
            echo "Błąd dodawania podstrony: " . mysqli_error($link);
        }
    }

    echo '<h3>Dodaj Nową Podstronę</h3>';
    echo '<form method="post" action="">
            Tytuł: <input type="text" name="page_title" value="" required /><br>
            Treść: <textarea name="content" required></textarea><br>
            Aktywna: <input type="checkbox" name="active"><br>
            <input type="hidden" name="action" value="add" />
            <input type="submit" value="Dodaj Podstronę" />
          </form>';
}
DodajNowaPodstrone();


function DodajKategorie($nazwa, $matka = 0) {
    global $link;

    // Zabezpieczenie danych wejściowych
    $nazwa = mysqli_real_escape_string($link, $nazwa);
    $matka = (int)$matka;

    // Dodawanie kategorii
    $query = "INSERT INTO kategorie (nazwa, matka) VALUES ('$nazwa', $matka)";
    if (mysqli_query($link, $query)) {
        echo "Kategoria została dodana!";
    } else {
        echo "Błąd podczas dodawania kategorii: " . mysqli_error($link);
    }
}
function EdytujKategorie($id, $nazwa, $matka) {
    global $link;

    // Zabezpieczenie danych wejściowych
    $id = (int)$id;
    $nazwa = mysqli_real_escape_string($link, $nazwa);
    $matka = (int)$matka;

    // Aktualizacja kategorii
    $query = "UPDATE kategorie SET nazwa = '$nazwa', matka = $matka WHERE id = $id LIMIT 1";
    if (mysqli_query($link, $query)) {
        echo "Kategoria została zaktualizowana!";
    } else {
        echo "Błąd podczas aktualizacji kategorii: " . mysqli_error($link);
    }
}
function UsunKategorie($id) {
    global $link;

    $id = (int)$id;

    // Usunięcie kategorii
    $query = "DELETE FROM kategorie WHERE id = $id LIMIT 1";
    if (mysqli_query($link, $query)) {
        echo "Kategoria została usunięta!";
    } else {
        echo "Błąd podczas usuwania kategorii: " . mysqli_error($link);
    }
}
function PokazKategorie($matka = 0, $poziom = 1) {
    global $link;

    // Przygotowanie zapytania do bazy danych
    $query = "SELECT * FROM kategorie WHERE matka = $matka";
    $result = mysqli_query($link, $query);

    // Obsługa błędów zapytania SQL
    if (!$result) {
        echo "Błąd zapytania: " . mysqli_error($link);
        return;
    }

    // Wyświetlanie kategorii w formie drzewa
    while ($row = mysqli_fetch_assoc($result)) {
        // Wyświetlenie nazwy kategorii z odpowiednim wcięciem
        echo str_repeat('--', $poziom*3) . "ID: " . $row['id']. "  " . htmlspecialchars($row['nazwa']) . "<br>";

        // Rekurencyjne wywołanie dla podkategorii
        PokazKategorie($row['id'], $poziom + 1);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['dodaj_kategorie'])) {
        DodajKategorie($_POST['nazwa'], $_POST['matka']);
    } elseif (isset($_POST['edytuj_kategorie'])) {
        EdytujKategorie($_POST['id'], $_POST['nazwa'], $_POST['matka']);
    } elseif (isset($_POST['usun_kategorie'])) {
        UsunKategorie($_POST['id']);
    }
}

//Wyświetlenie formularzy do zarządzania kategoriami

// -------------------------------
// Formularz dodawania kategorii
// -------------------------------
echo '<h2>Dodaj kategorię</h2>
<form method="post">
    Nazwa: <input type="text" name="nazwa" required><br>
    Matka: <input type="number" name="matka" value="0"><br> <!-- Wartość 0 oznacza kategorię główną -->
    <button type="submit" name="dodaj_kategorie">Dodaj</button>
</form>';

// -------------------------------
// Formularz edytowania kategorii
// -------------------------------
echo '<h2>Edytuj kategorię</h2>
<form method="post">
    ID kategorii: <input type="number" name="id" required><br>
    Nowa nazwa: <input type="text" name="nazwa" required><br>
    Matka: <input type="number" name="matka" value="0"><br> <!-- Wartość 0 oznacza kategorię główną -->
    <button type="submit" name="edytuj_kategorie">Edytuj</button>
</form>';

// -------------------------------
// Formularz usuwania kategorii
// -------------------------------
echo '<h2>Usuń kategorię</h2>
<form method="post">
    ID kategorii: <input type="number" name="id" required><br>
    <button type="submit" name="usun_kategorie" onclick="return confirm(\'Czy na pewno chcesz usunąć tę kategorię?\')">Usuń</button>
</form>';
PokazKategorie();





function DodajProdukt($dane) {
    global $link;

    // Zabezpieczenie danych wejściowych
    $tytul = mysqli_real_escape_string($link, $dane['tytul']);
    $opis = mysqli_real_escape_string($link, $dane['opis']);
    $data_wygasniecia = mysqli_real_escape_string($link, $dane['data_wygasniecia']);
    $cena_netto = (float)$dane['cena_netto'];
    $podatek_vat = (float)$dane['podatek_vat'];
    $ilosc = (int)$dane['ilosc'];
    $status = (int)$dane['status'];
    $kategoria_id = (int)$dane['kategoria_id'];
    $gabaryt = mysqli_real_escape_string($link, $dane['gabaryt']);
    $zdjecie = mysqli_real_escape_string($link, $dane['zdjecie']);

    // Zapytanie SQL
    $query = "INSERT INTO produkty (tytul, opis, data_utworzenia, data_modyfikacji, data_wygasniecia, cena_netto, podatek_vat, ilosc, status, kategoria_id, gabaryt, zdjecie)
              VALUES ('$tytul', '$opis', NOW(), NOW(), '$data_wygasniecia', $cena_netto, $podatek_vat, $ilosc, $status_dostepnosci, $kategoria_id, '$gabaryt', '$zdjecie')";

    if (mysqli_query($link, $query)) {
        echo "Produkt został dodany!";
    } else {
        echo "Błąd: " . mysqli_error($link);
    }
}

function EdytujProdukt($id, $dane) {
    global $link;

    // Zabezpieczenie danych wejściowych
    $id = (int)$id;


        // Zabezpieczenie danych wejściowych
    $id = (int)$id;

    // Sprawdzenie, czy produkt o podanym ID istnieje
    $query_check = "SELECT id FROM produkty WHERE id = $id LIMIT 1";
    $result_check = mysqli_query($link, $query_check);

    if (!$result_check || mysqli_num_rows($result_check) == 0) {
        echo "Błąd: Produkt o podanym ID ($id) nie istnieje.";
        return; // Przerywamy funkcję, jeśli produkt nie istnieje
    }
    
    $tytul = mysqli_real_escape_string($link, $dane['tytul']);
    $opis = mysqli_real_escape_string($link, $dane['opis']);
    $data_wygasniecia = mysqli_real_escape_string($link, $dane['data_wygasniecia']);
    $cena_netto = (float)$dane['cena_netto'];
    $podatek_vat = (float)$dane['podatek_vat'];
    $ilosc = (int)$dane['ilosc'];
    $status = (int)$dane['status'];
    $kategoria_id = (int)$dane['kategoria_id'];
    $gabaryt = mysqli_real_escape_string($link, $dane['gabaryt']);
    $zdjecie = mysqli_real_escape_string($link, $dane['zdjecie']);

    // Zapytanie SQL
    $query = "UPDATE produkty
              SET tytul = '$tytul', opis = '$opis', data_modyfikacji = NOW(), data_wygasniecia = '$data_wygasniecia',
                  cena_netto = $cena_netto, podatek_vat = $podatek_vat, ilosc = $ilosc, status = $status,
                  kategoria_id = $kategoria_id, gabaryt = '$gabaryt', zdjecie = '$zdjecie'
              WHERE id = $id LIMIT 1";

    if (mysqli_query($link, $query)) {
        echo "Produkt został zaktualizowany!";
    } else {
        echo "Błąd: " . mysqli_error($link);
    }
}
function UsunProdukt($id) {
    global $link;

    $id = (int)$id;

    $query = "DELETE FROM produkty WHERE id = $id LIMIT 1";
    if (mysqli_query($link, $query)) {
        echo "Produkt został usunięty!";
    } else {
        echo "Błąd: " . mysqli_error($link);
    }
}
function PokazProdukty() {
    global $link;

    $query = "SELECT * FROM produkty";
    $result = mysqli_query($link, $query);

    if ($result) {
        echo '<table border="1" cellpadding="5">';
        echo '<tr><th>ID</th><th>Tytuł</th><th>Cena netto</th><th>VAT</th><th>Ilość</th><th>Opcje</th></tr>';
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td>' . $row['id'] . '</td>';
            echo '<td>' . htmlspecialchars($row['tytul'], ENT_QUOTES, 'UTF-8') . '</td>';
            echo '<td>' . $row['cena_netto'] . ' zł</td>';
            echo '<td>' . $row['podatek_vat'] . ' %</td>';
            echo '<td>' . $row['ilosc'] . '</td>';
            echo '<td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="id" value="' . $row['id'] . '">
                        <button type="submit" name="edytuj">Edytuj</button>
                    </form>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="id" value="' . $row['id'] . '">
                        <button type="submit" name="usun">Usuń</button>
                    </form>
                  </td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo "Błąd: " . mysqli_error($link);
    }
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['dodaj'])) {
        DodajProdukt($_POST);
    } elseif (isset($_POST['edytuj'])) {
        EdytujProdukt($_POST['id'], $_POST);
    } elseif (isset($_POST['usun'])) {
        UsunProdukt($_POST['id']);
    }
}

echo '<h2>Zarządzaj produktami</h2>';
PokazProdukty();

echo '<h2>Dodaj Produkt</h2>
<form method="post">
    Tytuł: <input type="text" name="tytul" required><br>
    Opis: <textarea name="opis" required></textarea><br>
    Data wygaśnięcia: <input type="date" name="data_wygasniecia" required><br>
    Cena netto: <input type="number" step="0.01" name="cena_netto" required><br>
    Podatek VAT: <input type="number" step="0.01" name="podatek_vat" required><br>
    Ilość: <input type="number" name="ilosc" required><br>
    Status dostępności: <input type="checkbox" name="status"><br>
    Kategoria ID: <input type="number" name="kategoria_id" required><br>
    Gabaryt: <input type="text" name="gabaryt" required><br>
    Zdjęcie (link): <input type="text" name="zdjecie" required><br>
    <button type="submit" name="dodaj">Dodaj Produkt</button>
</form>';

echo '<h2>Edytuj Produkt</h2>
<form method="post">
    ID: <input type="number" name="id" required><br>
    Tytuł: <input type="text" name="tytul"><br>
    Opis: <textarea name="opis"></textarea><br>
    Data wygaśnięcia: <input type="date" name="data_wygasniecia"><br>
    Cena netto: <input type="number" step="0.01" name="cena_netto"><br>
    Podatek VAT: <input type="number" step="0.01" name="podatek_vat"><br>
    Ilość: <input type="number" name="ilosc"><br>
    Status dostępności: <input type="checkbox" name="status"><br>
    Kategoria ID: <input type="number" name="kategoria_id"><br>
    Gabaryt: <input type="text" name="gabaryt"><br>
    Zdjęcie (link): <input type="text" name="zdjecie"><br>
    <button type="submit" name="edytuj">Edytuj Produkt</button>
</form>';

echo '<h2>Usuń Produkt</h2>
<form method="post">
    ID: <input type="number" name="id" required><br>
    <button type="submit" name="usun">Usuń Produkt</button>
</form>';


?>
